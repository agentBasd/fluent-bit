# Fluent Bit Documentation

For every [Fluent Bit](https://fluentbit.io) release there is full documentation, the most updated documents can be found in the following link:

[https://docs.fluentbit.io/](https://docs.fluentbit.io/)

## Documentation Sources

If you are interested into provide some documentation contribution, please refer to the following GIT repository for more details:

[http://github.com/fluent/fluent-bit-docs](http://github.com/fluent/fluent-bit-docs)
